package product_purchased_most;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Pp_Mapper extends Mapper<LongWritable, Text, Text, IntWritable>{
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {
		String line= value.toString();
	        String[] words=line.split(",");
	        Text outputkey=new Text(words[1]);
	        IntWritable outputvalue=new IntWritable(1);
	        con.write(outputkey,outputvalue);
		}   
	}

